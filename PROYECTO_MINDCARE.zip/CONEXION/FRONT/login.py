import flet as ft
from BACK.backend import AuthService, Database

class UserAuthApp:

    user_id =  ""  #Variable para guadar el user id.
    username = "" #Varibale para guadar el nombre de usuario

    def __init__(self, page: ft.Page, on_login_success = None):

        #Variable del backend----------------------------------------
        self.db = Database()
        self.auth_service = AuthService(self.db)
        #------------------------------------------------------------

        self.page = page
        self.page.title = "User Login"
        self.page.vertical_alignment = ft.MainAxisAlignment.CENTER
        self.page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        self.users_db = {}
        self.on_login_success = on_login_success #Callbck para registrar login exitoso y hacer otras acciones.
        self.create_views()
    
    def check_password_input(self, e=None):
        self.password_toggle_icon.disabled = len(self.password_input.value.strip()) == 0
        self.page.update()

    def create_views(self):
        # Login view
        login_title = ft.Container(
            content=ft.Text(
                "Bienvenido a MINDCARE\nInicia sesión o regístrate para comenzar",
                size=30,
                weight=ft.FontWeight.BOLD,
                text_align=ft.TextAlign.CENTER
            ),
            padding=ft.Padding(0, 20, 0, 25)
        )
        self.username_input = ft.Container(
            content=ft.TextField(label="Username", width=300),
            padding=ft.Padding(0, 10, 0, 10)
        )
        self.password_input = ft.TextField(label="Password", width=250, password=True, on_change=self.check_password_input)
        self.password_toggle_icon = ft.IconButton(
            icon=ft.Icons.VISIBILITY_OFF,
            on_click=self.toggle_password_visibility,
            disabled=True
        )
        password_row = ft.Container(
            content=ft.Row(
                controls=[self.password_input, self.password_toggle_icon],
                alignment=ft.MainAxisAlignment.CENTER
            ),
            padding=ft.Padding(0, 10, 0, 10)
        )
        login_button = ft.Container(
            content=ft.ElevatedButton("Login", on_click=self.login),
            padding=ft.Padding(0, 10, 0, 1)
        )
        register_button = ft.Container(
            content=ft.TextButton("Register", on_click=self.switch_to_register),
            padding=ft.Padding(0, 1, 0, 10)
        )

        self.login_view = ft.Column(
            controls=[
                login_title,
                self.username_input,
                password_row,
                login_button,
                register_button
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            visible=True
        )

        # Register view
        register_title = ft.Container(
            content=ft.Text(
                "Crea una cuenta\nSi ya tienes una cuenta Inicia Sesión",
                size=30,
                weight=ft.FontWeight.BOLD,
                text_align=ft.TextAlign.CENTER
            ),
            padding=ft.Padding(0, 20, 0, 25)
        )
        self.reg_username_input = ft.Container(
            content=ft.TextField(label="New Username", width=300),
            padding=ft.Padding(0, 10, 0, 10)
        )
        self.reg_password_input = ft.TextField(label="New Password", width=250, password=True, on_change=self.check_register_password_input)
        self.reg_confirm_password_input = ft.TextField(label="Confirm Password", width=250, password=True, on_change=self.check_confirm_password_input)
        self.reg_confirm_password_toggle_icon = ft.IconButton(
            icon=ft.Icons.VISIBILITY_OFF,
            on_click=self.toggle_confirm_password_visibility,
            disabled=True
        )
        self.reg_password_toggle_icon = ft.IconButton(
            icon=ft.Icons.VISIBILITY_OFF,
            on_click=self.toggle_register_password_visibility,
            disabled=True
        )
        reg_password_row = ft.Container(
            content=ft.Row(
                controls=[self.reg_password_input, self.reg_password_toggle_icon],
                alignment=ft.MainAxisAlignment.CENTER
            ),
            padding=ft.Padding(0, 10, 0, 10)
        )
        reg_confirm_password_row = ft.Container(
            content=ft.Row(
                controls=[self.reg_confirm_password_input, self.reg_confirm_password_toggle_icon],
                alignment=ft.MainAxisAlignment.CENTER
            ),
            padding=ft.Padding(0, 10, 0, 10)
        )
        register_submit_button = ft.Container(
            content=ft.ElevatedButton("Register", on_click=self.register),
            padding=ft.Padding(0, 10, 0, 1)
        )
        back_to_login_button = ft.Container(
            content=ft.TextButton("Back to Login", on_click=self.switch_to_login),
            padding=ft.Padding(0, 1, 0, 10)
        )

        self.register_view = ft.Column(
            controls=[
                register_title,
                self.reg_username_input,
                reg_password_row,
                reg_confirm_password_row,
                register_submit_button,
                back_to_login_button
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            visible=False
        )

        self.page.add(self.login_view, self.register_view)

    def toggle_password_visibility(self, e):
        self.password_input.password = not self.password_input.password
        self.password_toggle_icon.icon = ft.Icons.VISIBILITY if not self.password_input.password else ft.Icons.VISIBILITY_OFF
        self.page.update()

    def toggle_register_password_visibility(self, e):
        self.reg_password_input.password = not self.reg_password_input.password
        self.reg_password_toggle_icon.icon = ft.Icons.VISIBILITY if not self.reg_password_input.password else ft.Icons.VISIBILITY_OFF
        self.page.update()

    def toggle_confirm_password_visibility(self, e):
        self.reg_confirm_password_input.password = not self.reg_confirm_password_input.password
        self.reg_confirm_password_toggle_icon.icon = ft.Icons.VISIBILITY if not self.reg_confirm_password_input.password else ft.Icons.VISIBILITY_OFF
        self.page.update()

    def check_register_password_input(self, e=None):
        self.reg_password_toggle_icon.disabled = len(self.reg_password_input.value.strip()) == 0
        self.page.update()

    def check_confirm_password_input(self, e=None):
        self.reg_confirm_password_toggle_icon.disabled = len(self.reg_confirm_password_input.value.strip()) == 0
        self.page.update()

    def login(self, e):
        username = self.username_input.content.value
        password = self.password_input.value

        #if username in self.users_db and self.users_db[username] == password:
        UserAuthApp.user_id = self.auth_service.login_user(username, password)
        if UserAuthApp.user_id:
            self.page.snack_bar = ft.SnackBar(ft.Text("Login successful!"), bgcolor=ft.colors.GREEN)
            UserAuthApp.username = username
            
            if self.on_login_success:  # Llama al callback si está definido.
                self.on_login_success()

        else:
            self.page.snack_bar = ft.SnackBar(ft.Text("Invalid credentials!"), bgcolor=ft.colors.RED)
        self.page.snack_bar.open = True
        self.page.update()

    def switch_to_register(self, e):
        self.login_view.visible = False
        self.register_view.visible = True
        self.page.update()

    def register(self, e):
        reg_username = self.reg_username_input.content.value
        reg_password = self.reg_password_input.value
        reg_confirm_password = self.reg_confirm_password_input.value

        if not reg_username or not reg_password or not reg_confirm_password:
            self.page.snack_bar = ft.SnackBar(ft.Text("Please fill all fields!"), bgcolor=ft.colors.RED)
        elif reg_password != reg_confirm_password:
            self.page.snack_bar = ft.SnackBar(ft.Text("Passwords do not match!"), bgcolor=ft.colors.RED)
        else:
            #self.users_db[reg_username] = reg_password
    
            if self.auth_service.register_user(reg_username, reg_password):
                self.page.snack_bar = ft.SnackBar(ft.Text("Registration successful!"), bgcolor=ft.colors.GREEN)
            else:
                self.page.snack_bar = ft.SnackBar(ft.Text("Error al registrar usuario"), bgcolor=ft.colors.RED)

            self.reg_username_input.content.value = ""
            self.reg_password_input.value = ""
            self.reg_confirm_password_input.value = ""
            self.switch_to_login(None)
        self.page.snack_bar.open = True
        self.page.update()

    def switch_to_login(self, e):
        self.register_view.visible = False
        self.login_view.visible = True
        self.page.update()

    def close_app(self):
        self.page.window_close()  # Cierra la ventana de la aplicación

""""
def main(page: ft.Page):
    UserAuthApp(page)

ft.app(target=main)
"""