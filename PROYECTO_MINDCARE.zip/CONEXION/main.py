import flet as ft
from FRONT.login import UserAuthApp
from FRONT.principal import ChatApp

#Importacion de backend para pruebas-----
from BACK.backend import ChatService, Database, ChatApplication
#----------------------------------------

def log(page: ft.Page):

    def cambiar_pantalla(nueva_pantalla):
        """Limpia la UI y cambia a la nueva pantalla."""
        page.controls.clear()
        nueva_pantalla()
        page.update()

    def on_login_success(e=None):
        print("Login exitoso. Cambiando a la pantalla principal...")
        cambiar_pantalla(ventana_principal)

    def ventana_principal():
        """Carga la pantalla principal con opción de cerrar sesión."""
        app = ChatApp(page, on_logout=volver_a_login)
        app.build_ui()

    def volver_a_login(e=None):
        """Regresa a la pantalla de inicio de sesión."""
        print("Cerrando sesión. Regresando a pantalla de inicio de sesión...")
        cambiar_pantalla(pantalla_login)

    def pantalla_login():
        """Carga la pantalla de login."""
        app = UserAuthApp(page, on_login_success=on_login_success)
        #app.build_ui()

    # Iniciar con la pantalla de login
    print("Cargando pantalla de inicio de sesión...")
    pantalla_login()


""""
#Pruebas de listas-------------------------
db = Database()
print(ChatService(db).get_user_sessions(16))
print(ChatService(db).load_messages(40))
print(ChatService(db).load_messages(41))
print(ChatService(db).load_messages(42))
print("---------------------------------------------------------------------------------------------------------------------------------------")
#-------------------------------------------
"""

ft.app(target=log)
